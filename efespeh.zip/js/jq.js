$("#btnEdit").click(function(){
    var kode = $("#cmbMataKuliah").val();
    window.location.replace("ubahpeserta.php");
})